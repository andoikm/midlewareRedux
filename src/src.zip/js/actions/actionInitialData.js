import {GET_INITIAL_DATA} from "./actionTypes/index";


export const GetData = (payload) => {
    return {
        type: GET_INITIAL_DATA,
        payload
    };
};
